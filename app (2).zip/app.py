from flask import Flask, flash, redirect, render_template, request, session, abort,url_for
from sqlalchemy import create_engine
from decimal import Decimal
import json
import os
import pandas as pd
#Defining input variables with input values from nigel file
BaseSupport = 3426.74
TeacherCompAmount = 3469.57425
TeacherCompPercent = 1.25
Amount200DayCalender = 3598.077
Percent200DayCalender = 5
TeacherCompAnd200DayCalender = 3643.052963
FullDayKindergarten10 = 0
GroupABasePSD = 1
GroupAGradeLevelPSD = 0
GroupAPSD = 0.45
GroupAFinalGroupAWeightsPSD = 1.45
GroupABaseK_8 = 1
GroupAGradeLevelK_8 = 0
GroupAK_8 = 0.158
GroupAFinalGroupAWeightsK_8 = 1.158
GroupABase9_12 = 1
GroupAGradeLevel9_12 = 0.163
GroupA9_12 = 0.105
GroupAFinalGroupAWeights9_12 = 1.268
GroupABaseJTED = 1
GroupAGradeLevelJTED = 0.339
GroupAJTED = 0
GroupAFinalGroupAWeightsJTED = 1.339
WtSmallIso1to99K_8 = 1.559
WtSmallIso100to499K_8 = 1.358
WtSmallIso500to599K_8 = 1.158
WtSmallIso600AndOverK_8 = 0
WtSmall1to99K_8 = 1.399
WtSmall100to499K_8 = 1.278
WtSmall500to599K_8 = 1.158
WtSmall600AndOverK_8 = 0
WtSmallIso1to999_12 = 1.669
WtSmallIso100to4999_12 = 1.468
WtSmallIso500to5999_12 = 1.268
WtSmallIso600AndOver9_12 = 0
WtSmall1to999_12 = 1.559
WtSmall100to4999_12 = 1.398
WtSmall500to5999_12 = 1.268
WtSmall600AndOver9_12 = 0
IncWtSmallIso1to99K_8 = 0
IncWtSmallIso100to499K_8 = 0.0005
IncWtSmallIso500to599K_8 = 0.002
IncWtSmallIso600AndOverK_8 = 0
IncWtSmall1to99K_8 = 0
IncWtSmall100to499K_8 = 0.0003
IncWtSmall500to599K_8 = 0.0012
IncWtSmall600AndOverK_8 = 0
IncWtSmallIso1to999_12 = 0
IncWtSmallIso100to4999_12 = 0.0005
IncWtSmallIso500to5999_12 = 0.002
IncWtSmallIso600AndOver9_12 = 0
IncWtSmall1to999_12 = 0
IncWtSmall100to4999_12 = 0.0004
IncWtSmall500to5999_12 = 0.0013
IncWtSmall600AndOver9_12 = 0
GroupB1 = 0.0013
GroupB2 = 0.04
GroupB3 = 0.06
GroupB4 = 0.115
GroupB5 = 3.158
GroupB6 = 3.595
GroupB7 = 4.421
GroupB8 = 4.771
GroupB9 = 4.806
GroupB10 = 4.822
GroupB11 = 5.833
GroupB12 = 6.024
GroupB13 = 6.773
GroupB14 = 7.947
PolicyOption1 = 0
TEI10 = 1
FullTimeAOI = 0.95
HalfTimeAOI = 0.85
Transportation123TSL = 1
TransportationPerPupilOptionTRCL = 0
DistSuppLvlAllPSD = 450.76
DistSuppLvl1to99K_8 = 544.58
DistSuppLvl100to599K_8 = 389.25
DistSuppLvl600AndOverK_8 = 450.76
DistSuppLvl1to999_12 = 601.24
DistSuppLvl100to5999_12 = 405.59
DistSuppLvl600AndOver9_12 = 492.94
CharSuppLvlAllK_8 = 1752.1
CharSuppLvlAll9_12 = 2042.04
DistHSTxtBkAllPSD = 0
DistHSTxtBk1to99K_8 = 0
DistHSTxtBk100to599K_8 = 0
DistHSTxtBk600AndOverK_8 = 0
DistHSTxtBk1to999_12 = 69.68
DistHSTxtBk100to5999_12 = 69.68
DistHSTxtBk600AndOver9_12 = 69.68
CharHSTxtBkAllK_8 = 0
CharHSTxtBkAll9_12 = 0
Reduction10 = 1
AdditionalAssistant_eqformula = 1
DistrictReduction = 352442700
ActualDistrictReduction = -381355874.7
CharterReduction = 18656000
AvgDistrictPPReduction = 382.77165
AvgActualDistReduction = -414.1729064
AvgCharterPPReduction = 109.6679608
AdditonalAssistantReduction=1
QTRK_8 = 2.0977
QTR9_12 = 2.0977
QTRUnified = 4.1954
QTRJTED = 0.05

class CustomJsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(CustomJsonEncoder, self).default(obj)
app = Flask(__name__)
app.secret_key = 'asfmasgma'
app._static_folder = os.path.abspath("C:/Users/jjoth/PycharmProjects/untitled1/templates/static/")
#ESHTABLISHING CONNECTION
engine = create_engine('mysql+pymysql://DCEdExUser1:DCEdExUser1@dcedex.cgnkf5ysjn5z.us-west-1.rds.amazonaws.com/DCSchoolFinance')
@app.route('/',methods=['GET','POST'])
def home():
    return render_template('login.html')
@app.route('/login', methods=['POST','GET'])
def login():
    ll=0
    usercheck = engine.execute('Select * from userLogin')
    for i in usercheck:
        if request.form['password'] == i[1] and request.form['username'] == i[0]:
            ll+=1
            session['username'] = request.form['username']
            return wftf()
    if ll==0:
        error = 'Invalid Credentials. Please try again.'
        return render_template("login.html", error=error)

@app.route('/logout',methods=['GET', 'POST'])
def logout():

        return render_template('login.html')

#CALCULATION OF VALUES
@app.route('/wftf',methods=['GET','POST'])
def wftf():
#ASSIGNING VARIABLES FOR CALCULATION
   SSWELEMINCREMENTALWEIGHTPP = []
   SSWHSINCREMENTALWEIGHTPP = []
   fDK = 0
   PREKADM = []
   PrekBSL = []
   HSADM = []
   ELEMADM=[]
   ELEMBSL=[]
   HSBSL=[]
   sixtyseven=67
   CharterElemAA=[]
   CharterHSAA=[]
   CharterElemADM=[]
   CharterHSADM=[]
   LEApercentofCharterElemADM=[]
   LEApercentofCharterHSADM=[]
   K_8PercentofTotalcharterAA=[]
   TotalCharterElemReduction=[]
   TotalCharterHSReduction=[]
   CharterElemAAReduction=[]
   CharterHSAAReduction=[]
   TotalNetCharterAA=[]
   DistrictHSTextbooksAA=[]
   DistrictHSAA=[]
   DistrictElemAA=[]
   DistrictPreKAA=[]
   TotalFormulaDistrictAA=[]
   DistrictPreKElemReduction=[]
   DistrictHSReduction=[]
   TotalDistrictAAReduction=[]
   TotalNetDistrictAA=[]
   NetworkElemADM=[]
   NetworkHSADM=[]
   sumofnetworkelemadm={}
   sumofnetworkhsadm={}
   FinalFormulaAAwithReduction=[]
   AdditionalAssistance = []
   HSRange=[]
   ELEMRange=[]
   TotalStateEqualisationFunding=[]
   OppurtunityWeight=[]
   TRCL=[]
   TSL=[]
   RCL=[]
   DSL=[]
   SumofPreKWeightedPupilsuser_specifiedSWWreduction={}
   Sumofk_8WeightedPupilsuser_specifiedSWWreduction={}
   Sumof9_12WeightedPupilsuser_specifiedSWWreduction={}

   #STORE THE NETWORK NAMES
   parentorg = engine.execute('select distinct (ParentOrganization) from ChartersWithNetwork')
   for row2 in parentorg:
       d2=row2[0]
       if d2 !='':
           sumofnetworkelemadm[d2]=0
           sumofnetworkhsadm[d2]=0
   count=0
#CALCULATION OF ADM VALUES
   preresult = engine.execute('select truck.*,lorry.PsdCapOutlayRevLimitAmt,lorry.ElemCapOutlayRevLimitAmt,lorry.HsPrlmCapOutlayRevLimitAmt,lorry.HsBooksCapOutlayRevLimitAmt,lorry.PSElTransAdj,lorry.HSTransAdj from (select kvs.*, CSH.parentOrganization, CSH.NetworkForFundingPurposes, CSH.ESSmallIsolated, CSH.HSSmallIsolated from (select ftfmaintype.*,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (Select ftfmain.*,EntityName,Entityshort.County,Entityshort.Type from (select EntityID,sum(PsdCount) as sumOfPsdCount,sum(ElemCount) as sumOfElemCount,sum(DSCSElemCnt) as sumOfDSCSElemCount,sum(HsCount) as sumOfHsCount, sum(DSCSHsCnt) as sumOfDSCSHsCount, FiscalYear,TEI,BaseAmount as MaxOfBaseAmount,sum(MDSSICnt) as sumOfMDSSICnt, sum(DSCSMDSSICnt)as sumOfDSCSMDSSICnt, sum(DSCSVICnt)as sumOfDSCSVICnt, sum(DSCSOISCCnt) as sumOfDSCSOISCCnt, sum(DSCSPSDCnt)as sumOfDSCSPSDCnt, sum(DSCSMDSCCnt)as sumOfDSCSMDSCCnt, sum(DSCSHICnt)as sumOfDSCSHICnt, sum(DSCSMOMRCnt)as sumOfDSCSMOMRCnt, sum(DSCSEDPPrivateCnt)as sumOfDSCSEDPPrivateCnt, sum(DSCSMDResCnt)as sumOfDSCSMDResCnt, sum(DSCSOIResCnt)as sumOfDSCSOIResCnt, sum(DSCSEDMIMRCnt)as sumOfDSCSEDMIMRCnt, sum(DSCSLEPCnt)as sumOfDSCSLEPCnt, sum(DSCSK3Cnt)as SumOfDSCSK3Cnt, sum(PSDCnt)as sumOfPSDCnt, sum(VICnt)as sumOfVICnt, sum(OISCCnt)as sumOfOISCCnt, sum(MDSCCnt)as sumOfMDSCCnt, sum(HICnt)as sumOfHICnt, sum(MOMRCnt)as sumOfMOMRCnt, sum(EDPPrivateCnt)as sumOfEDPPrivateCnt, sum(MDResCnt)as sumOfMDResCnt, sum(OIResCnt)as sumOfOIResCnt, sum(EDMIMRCnt)as sumOfEDMIMRCnt, sum(LEPCnt)as sumOfLEPCnt, sum(K3Cnt)as sumOfK3Cnt, FTFStatus from (select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaAporBaseSupportLevelCalcs where PaymentMonth=14 union all select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaCharBaseSupportLevelCalcs where PaymentMonth=13)uni where FiscalYear=2017 group by EntityID,FTFStatus )ftfmain left join (select EntityID,EntityName,County,Entity.Type from Entity)Entityshort on ftfmain.EntityID=Entityshort.EntityID )ftfmaintype left join (select TRCLTSL.EntityID,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (select TRCL.EntityID,TRCL,TSL from (select EntityID,TRCL from SaAporTransRevCtlLimit where FiscalYear=2017 and PaymentMonth=14)TRCL left join (select EntityID,TSL from SaAporTransSupptLvl where FiscalYear=2017 and PaymentMonth=14)TSL on TRCL.EntityID=TSL.EntityID)TRCLTSL left join (Select EntityID,TotalPSElAssessValAmt,TotalHSAssessValAmt from SaAporQualLevy where FiscalYear=2017 and PaymentMonth=14)PSEl on TRCLTSL.EntityID=PSEl.EntityID )Bike on ftfmaintype.EntityID=Bike.EntityID) kvs left join (select CWN.EntityID, CWN.EntityName, CWN.parentOrganization, CWN.NetworkForFundingPurposes, ESSmallIsolated, HSSmallIsolated from (select EntityID, ChartersWithNetwork.OrganizationName as EntityName, ParentOrganization, ifnull(Charters4Funding.NetworkForFundingPurposes,0) as NetworkForFundingPurposes  from ChartersWithNetwork left join Charters4Funding on ChartersWithNetwork.ParentOrganization = Charters4Funding.OrganizationName) CWN left join SmallIsolatedList on CWN.EntityID = SmallIsolatedList.EntityID)CSH on kvs.EntityID = CSH.EntityID)truck left join(select car1.EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt,PSElTransAdj,HSTransAdj from (select EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt from SaAporCapitalOutlayCalcs where FiscalYear=2017 and PaymentMonth=14 )bike1 left join (select EntityID,PSElTransAdj,HSTransAdj from SaAporSoftCapAlloc where FiscalYear=2017 and PaymentMonth=14 )car1 on car1.EntityID=bike1.EntityID)lorry on lorry.EntityID=truck.EntityID')
   for prerow in preresult:
       pred = dict(prerow.items())
       d3=pred['EntityID']
       SumofPreKWeightedPupilsuser_specifiedSWWreduction[d3]=0
       Sumofk_8WeightedPupilsuser_specifiedSWWreduction[d3]=0
       Sumof9_12WeightedPupilsuser_specifiedSWWreduction[d3]=0
       #MAKING THE TYPE OF SCHOOL COMPACT FOR CALCULATIONS
       if (pred['Type'] == 'Charter Holder-Charter Board'):
           pred['Type']="Charter"

       elif (pred['Type'] =='Charter Holder - University'):
           pred['Type']="Charter"
       elif (pred['Type']== 'School District - Vocational/Technical'):
           pred['Type']="JTED"
       else:
           pred['Type']="District"
       # calculation of PREKADM

       if pred['sumOfPsdCount'] == None:
           pred['sumOfPsdCount'] = 0

       PREKADM.append(Decimal(pred['sumOfPsdCount']))

       # CALCULATION OF ELEM ADM
       if pred['sumOfElemCount'] == None:
           pred['sumOfElemCount'] = 0
       if pred['sumOfDSCSElemCount'] == None:
           pred['sumOfDSCSElemCount'] = 0

       ELEMADM.append(pred['sumOfElemCount'] + pred['sumOfDSCSElemCount'])
       #CALCULATION OF HSADM VALUE
       if pred['sumOfHsCount'] == None:
           pred['sumOfHsCount'] = 0
       if pred['sumOfDSCSHsCount'] == None:
           pred['sumOfDSCSHsCount'] = 0
       HSADM.append(pred['sumOfHsCount'] + pred['sumOfDSCSHsCount'])
       if pred['NetworkForFundingPurposes']==1:
           sumofnetworkelemadm[pred['ParentOrganization']]+=ELEMADM[count]
           sumofnetworkhsadm[pred['ParentOrganization']]+=HSADM[count]
       #CALCULATION OF CHARTERELEMENTARY AA AND ADM VALUES
       if pred['Type']=="Charter":
           CharterElemAA.append(Decimal(CharSuppLvlAllK_8)*Decimal(ELEMADM[count]))
           CharterHSAA.append(Decimal(CharSuppLvlAll9_12)*Decimal(HSADM[count]))
           CharterElemADM.append(Decimal(ELEMADM[count]))
           CharterHSADM.append(Decimal(HSADM[count]))
       else:
           CharterElemAA.append(0)
           CharterHSAA.append(0)
           CharterElemADM.append(0)
           CharterHSADM.append(0)
       count+=1
   #CARRYING ON NEXT STEPS OF CALCULATION
   result = engine.execute('select truck.*,lorry.PsdCapOutlayRevLimitAmt,lorry.ElemCapOutlayRevLimitAmt,lorry.HsPrlmCapOutlayRevLimitAmt,lorry.HsBooksCapOutlayRevLimitAmt,lorry.PSElTransAdj,lorry.HSTransAdj from (select kvs.*, CSH.parentOrganization, CSH.NetworkForFundingPurposes, CSH.ESSmallIsolated, CSH.HSSmallIsolated from (select ftfmaintype.*,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (Select ftfmain.*,EntityName,Entityshort.County,Entityshort.Type from (select EntityID,sum(PsdCount) as sumOfPsdCount,sum(ElemCount) as sumOfElemCount,sum(DSCSElemCnt) as sumOfDSCSElemCount,sum(HsCount) as sumOfHsCount, sum(DSCSHsCnt) as sumOfDSCSHsCount, FiscalYear,TEI,BaseAmount as MaxOfBaseAmount,sum(MDSSICnt) as sumOfMDSSICnt, sum(DSCSMDSSICnt)as sumOfDSCSMDSSICnt, sum(DSCSVICnt)as sumOfDSCSVICnt, sum(DSCSOISCCnt) as sumOfDSCSOISCCnt, sum(DSCSPSDCnt)as sumOfDSCSPSDCnt, sum(DSCSMDSCCnt)as sumOfDSCSMDSCCnt, sum(DSCSHICnt)as sumOfDSCSHICnt, sum(DSCSMOMRCnt)as sumOfDSCSMOMRCnt, sum(DSCSEDPPrivateCnt)as sumOfDSCSEDPPrivateCnt, sum(DSCSMDResCnt)as sumOfDSCSMDResCnt, sum(DSCSOIResCnt)as sumOfDSCSOIResCnt, sum(DSCSEDMIMRCnt)as sumOfDSCSEDMIMRCnt, sum(DSCSLEPCnt)as sumOfDSCSLEPCnt, sum(DSCSK3Cnt)as SumOfDSCSK3Cnt, sum(PSDCnt)as sumOfPSDCnt, sum(VICnt)as sumOfVICnt, sum(OISCCnt)as sumOfOISCCnt, sum(MDSCCnt)as sumOfMDSCCnt, sum(HICnt)as sumOfHICnt, sum(MOMRCnt)as sumOfMOMRCnt, sum(EDPPrivateCnt)as sumOfEDPPrivateCnt, sum(MDResCnt)as sumOfMDResCnt, sum(OIResCnt)as sumOfOIResCnt, sum(EDMIMRCnt)as sumOfEDMIMRCnt, sum(LEPCnt)as sumOfLEPCnt, sum(K3Cnt)as sumOfK3Cnt, FTFStatus from (select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaAporBaseSupportLevelCalcs where PaymentMonth=14 union all select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaCharBaseSupportLevelCalcs where PaymentMonth=13)uni where FiscalYear=2017 group by EntityID,FTFStatus )ftfmain left join (select EntityID,EntityName,County,Entity.Type from Entity)Entityshort on ftfmain.EntityID=Entityshort.EntityID )ftfmaintype left join (select TRCLTSL.EntityID,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (select TRCL.EntityID,TRCL,TSL from (select EntityID,TRCL from SaAporTransRevCtlLimit where FiscalYear=2017 and PaymentMonth=14)TRCL left join (select EntityID,TSL from SaAporTransSupptLvl where FiscalYear=2017 and PaymentMonth=14)TSL on TRCL.EntityID=TSL.EntityID)TRCLTSL left join (Select EntityID,TotalPSElAssessValAmt,TotalHSAssessValAmt from SaAporQualLevy where FiscalYear=2017 and PaymentMonth=14)PSEl on TRCLTSL.EntityID=PSEl.EntityID )Bike on ftfmaintype.EntityID=Bike.EntityID) kvs left join (select CWN.EntityID, CWN.EntityName, CWN.parentOrganization, CWN.NetworkForFundingPurposes, ESSmallIsolated, HSSmallIsolated from (select EntityID, ChartersWithNetwork.OrganizationName as EntityName, ParentOrganization, ifnull(Charters4Funding.NetworkForFundingPurposes,0) as NetworkForFundingPurposes  from ChartersWithNetwork left join Charters4Funding on ChartersWithNetwork.ParentOrganization = Charters4Funding.OrganizationName) CWN left join SmallIsolatedList on CWN.EntityID = SmallIsolatedList.EntityID)CSH on kvs.EntityID = CSH.EntityID)truck left join(select car1.EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt,PSElTransAdj,HSTransAdj from (select EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt from SaAporCapitalOutlayCalcs where FiscalYear=2017 and PaymentMonth=14 )bike1 left join (select EntityID,PSElTransAdj,HSTransAdj from SaAporSoftCapAlloc where FiscalYear=2017 and PaymentMonth=14 )car1 on car1.EntityID=bike1.EntityID)lorry on lorry.EntityID=truck.EntityID')
   #DEFINING VARIABLES FOR FURTHER CALCULATION
   Final_9_12SmWgt=[]
   Final_K_8SmWgt = []
   AuditBaseLevelAdjustment = []
   ddd=0
   FinalFormulaAdditionalAssistance=[]
   FinalAAAllocation=[]
   EID=[]
   Ename=[]
   D=[]
   BSL=[]
   TEI =[]
   LEABaseLevel =[]
   WeightedElemCounts=[]
   WeightedHSCounts=[]
   GroupBWeightedAddonCounts=[]
   ElemBaseWeight = []
   HSBaseWeight = []
   GroupBBSL = []
   WeightedPreKCounts = []
   GB1_EDMIDSLD=[]
   GB2_K3Reading=[]
   GB3_K3=[]
   GB4_ELL=[]
   GB5_OI_R=[]
   GB6_PS_D=[]
   GB7_MOID=[]
   GB8_HI=[]
   GB9_VI=[]
   GB10_ED_P=[]
   GB11_MDSC=[]
   GB12_MD_R=[]
   GB13_OI_SC=[]
   GB14_MD_SSI=[]
   AC1=[]
   AH=[]
   AI=[]
   Weighted_GB1_EDMIDSLD=[]
   Weighted_GB2_K3Reading=[]
   Weighted_GB3_K3=[]
   Weighted_=[]
   Weighted_GB5_OI_R=[]
   Weighted_GB6_PS_D=[]
   Weighted_GB7_MOID=[]
   Weighted_GB8_HI=[]
   Weighted_GB9_VI=[]
   Weighted_GB10_ED_P=[]
   Weighted_GB11_MDSC=[]
   Weighted_GB12_MD_R=[]
   Weighted_GB13_OI_SC=[]
   Weighted_GB14_MD_SSI=[]
   PreKWeightedPupilsuser_specifiedSWWreduction=[]
   K_8WeightedPupilsuser_specifiedSWWreduction=[]
   nine_12WeightedPupilsuser_specifiedSWWreduction=[]
   PercPreK_8ofTotal=[]
   PercHSofTotal=[]
   AB2=[]
   AC2=[]
   ElemAssessedValuation=[]
   ElemTotalStateFormula=[]
   HSTotalStateFormula=[]
   HSAssessedValuation=[]
   ElemQTRYield=[]
   HSQTRYield=[]
   HSLL=[]
   ElemLL=[]
   TotalLocalLevy=[]
   ElemStateAid=[]
   HSStateAid=[]
   TotalStateAid=[]
   ElemNoStateAidDistrict=[]
   HSNoStateAidDistrict=[]
   NoStateAidDistrict=[]
   TotalQTRYield=[]
   UncapturedQTR=[]
   TotalStateFundingEqualised=[]
   #PERFORMING BSL CALCULATION
   for row in result:

       #Creating a dictionary of the values retrieved from the query
       d = dict(row.items())
       #MAKING THE TYPE OF SCHOOL COMPACT FOR CALCULATIONS
       if (d['Type'] == 'Charter Holder-Charter Board'):
           d['Type']="Charter"

       elif (d['Type'] =='Charter Holder - University'):
           d['Type']="Charter"
       elif (d['Type']== 'School District - Vocational/Technical'):
           d['Type']="JTED"
       else:
           d['Type']="District"

       #CALCULATION OF ELEMENTARY RANGE AND NETWORK RANGES FOR WEIGHT CALCULATION
       if d['NetworkForFundingPurposes']==1:
           NetworkElemADM.append(sumofnetworkelemadm[d['ParentOrganization']])
           NetworkHSADM.append(sumofnetworkhsadm[d['ParentOrganization']])
           if NetworkHSADM[ddd] >= Decimal(1) and NetworkHSADM[ddd] < Decimal(100):
               HSRange.append("1to99")
           elif NetworkHSADM[ddd] >= Decimal(100) and NetworkHSADM[ddd] < Decimal(500):
               HSRange.append("100to499")
           elif NetworkHSADM[ddd] >= (Decimal(500)) and NetworkHSADM[ddd] < (Decimal(600)):
               HSRange.append("500to599")
           elif (NetworkHSADM[ddd] >= Decimal(600)):
               HSRange.append(">600")
           else:
               HSRange.append(None)

           if NetworkElemADM[ddd] >= Decimal(1) and NetworkElemADM[ddd] < Decimal(100):
               ELEMRange.append("1to99")
           elif NetworkElemADM[ddd] >= Decimal(100) and NetworkElemADM[ddd] < Decimal(500):
               ELEMRange.append("100to499")
           elif NetworkElemADM[ddd] >= (Decimal(500)) and NetworkElemADM[ddd] < (Decimal(600)):
               ELEMRange.append("500to599")
           elif (NetworkElemADM[ddd] >= Decimal(600)):
               ELEMRange.append(">600")
           else:
               ELEMRange.append(None)
       else:
           NetworkElemADM.append(0)
           NetworkHSADM.append(0)
           if HSADM[ddd] >= Decimal(1) and HSADM[ddd] < Decimal(100):
               HSRange.append("1to99")
           elif HSADM[ddd] >= Decimal(100) and HSADM[ddd] < Decimal(500):
               HSRange.append("100to499")
           elif HSADM[ddd] >= (Decimal(500)) and HSADM[ddd] < (Decimal(600)):
               HSRange.append("500to599")
           elif (HSADM[ddd] >= Decimal(600)):
               HSRange.append(">600")
           else:
               HSRange.append(None)
           if ELEMADM[ddd] >= Decimal(1) and ELEMADM[ddd] < Decimal(100):
               ELEMRange.append("1to99")
           elif ELEMADM[ddd] >= Decimal(100) and ELEMADM[ddd] < Decimal(500):
               ELEMRange.append("100to499")
           elif ELEMADM[ddd] >= (Decimal(500)) and ELEMADM[ddd] < (Decimal(600)):
               ELEMRange.append("500to599")
           elif (ELEMADM[ddd] >= Decimal(600)):
               ELEMRange.append(">600")
           else:
               ELEMRange.append(None)

       #CALCULATION OF SSWHSINCREMENTALWEIGHTPP
       if(d['Type']=="JTED"):
          SSWHSINCREMENTALWEIGHTPP.append(GroupAFinalGroupAWeightsJTED)
       else:
          if d['HSSmallIsolated']==1:
              if HSRange[ddd]=="1to99":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmallIso1to999_12)
              elif HSRange[ddd]=="100to499":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmallIso100to4999_12)
              elif HSRange[ddd]=="500to599":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmallIso500to5999_12)
              else:
                  SSWHSINCREMENTALWEIGHTPP.append(GroupAFinalGroupAWeights9_12)
          elif d['HSSmallIsolated']==0:
              if HSRange[ddd]=="1to99":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmall1to999_12)
              elif HSRange[ddd]=="100to499":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmall100to4999_12)
              elif HSRange[ddd]=="500to599":
                  SSWHSINCREMENTALWEIGHTPP.append(IncWtSmall500to5999_12)
              else:
                  SSWHSINCREMENTALWEIGHTPP.append(GroupAFinalGroupAWeights9_12)
          else:
              SSWHSINCREMENTALWEIGHTPP.append(GroupAFinalGroupAWeights9_12)

       # CALCULATION OF SSWELEMINCREMENTALWEIGHTPP
       if d['ESSmallIsolated'] == 1:
           if ELEMRange[ddd]=="1to99":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmallIso1to99K_8)
           elif ELEMRange[ddd]=="100to499":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmallIso100to499K_8)
           elif ELEMRange[ddd]=="500to599":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmallIso500to599K_8)
           else:
               SSWELEMINCREMENTALWEIGHTPP.append(0)
       elif d['ESSmallIsolated'] == 0:
           if ELEMRange[ddd]=="1to99":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmall1to99K_8)
           elif ELEMRange[ddd]=="100to499":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmall100to499K_8)
           elif ELEMRange[ddd]=="500to599":
               SSWELEMINCREMENTALWEIGHTPP.append(IncWtSmall500to599K_8)
           else:
               SSWELEMINCREMENTALWEIGHTPP.append(0)
       else:
           SSWELEMINCREMENTALWEIGHTPP.append(0)
       #CALCULATION OF FinalHSBASEWEIGHT
       if(d['Type']=="JTED"):
           HSBaseWeight.append(0)
       else:
           if d['HSSmallIsolated'] == 1:
               if HSRange[ddd]=="1to99":
                   HSBaseWeight.append(WtSmallIso1to999_12)
               elif HSRange[ddd]=="100to499":
                   HSBaseWeight.append(WtSmallIso100to4999_12)
               elif HSRange[ddd]=="500to599":
                   HSBaseWeight.append(WtSmallIso500to5999_12)
               else:
                   HSBaseWeight.append(0)
           elif d['HSSmallIsolated'] == 0:
               if HSRange[ddd]=="1to99":
                   HSBaseWeight.append(WtSmall1to999_12)
               elif HSRange[ddd]=="100to499":
                   HSBaseWeight.append(WtSmall100to4999_12)
               elif HSRange[ddd]=="500to599":
                   HSBaseWeight.append(WtSmall500to5999_12)
               else:
                   HSBaseWeight.append(0)
           else:
               HSBaseWeight.append(0)
       #CALCUATION OF Final9-12WEIGHT
       if d['Type']=="JTED":
           Final_9_12SmWgt.append(GroupAFinalGroupAWeightsJTED)
       else:
           if HSRange[ddd]==">600":
               Final_9_12SmWgt.append(GroupAFinalGroupAWeights9_12)
           elif HSADM[ddd]>=Decimal(1) and HSADM[ddd]<Decimal(100):
               Final_9_12SmWgt.append(HSBaseWeight[ddd])
           elif HSRange[ddd]=="100to499":
               Final_9_12SmWgt.append(Decimal(HSBaseWeight[ddd])+(Decimal(SSWHSINCREMENTALWEIGHTPP[ddd])*(Decimal(Decimal(500)-HSADM[ddd]))))
           elif HSRange[ddd]=="500to599":
               Final_9_12SmWgt.append(Decimal(HSBaseWeight[ddd]) + (Decimal(SSWHSINCREMENTALWEIGHTPP[ddd]) * (Decimal(Decimal(600) - HSADM[ddd]))))
           else:
               Final_9_12SmWgt.append(GroupAFinalGroupAWeights9_12)
       #CALCULATION OF FINALELEMBASEWEIGHT
       if d['ESSmallIsolated'] == 1:
           if ELEMRange[ddd]=="1to99":
               ElemBaseWeight.append(WtSmallIso1to99K_8)
           elif ELEMRange[ddd]=="100to499":
               ElemBaseWeight.append(WtSmallIso100to499K_8)
           elif ELEMRange[ddd]=="500to599":
               ElemBaseWeight.append(WtSmallIso500to599K_8)
           else:
               ElemBaseWeight.append(0)
       elif d['ESSmallIsolated'] == 0:
           if ELEMRange[ddd]=="1to99":
               ElemBaseWeight.append(WtSmall1to99K_8)
           elif ELEMRange[ddd]=="100to499":
               ElemBaseWeight.append(WtSmall100to499K_8)
           elif ELEMRange[ddd]=="500to599":
               ElemBaseWeight.append(WtSmall500to599K_8)
           else:
               ElemBaseWeight.append(0)
       else:
           ElemBaseWeight.append(0)
       #CALCUATION OF K-8WEIGHT
       if ELEMRange[ddd]==">600":
           Final_K_8SmWgt.append(GroupAFinalGroupAWeightsK_8)
       elif ELEMRange[ddd]=="1to99":
           Final_K_8SmWgt.append(ElemBaseWeight[ddd])
       elif ELEMRange[ddd]=="100to499":
           temp=Decimal(ElemBaseWeight[ddd])
           temp2=Decimal(SSWELEMINCREMENTALWEIGHTPP[ddd])
           temp3=Decimal(500 - ELEMADM[ddd])
           Final_K_8SmWgt.append(temp + (temp2 * (temp3)))
       elif ELEMRange[ddd]=="500to599":
           Final_K_8SmWgt.append(Decimal(ElemBaseWeight[ddd]) + (Decimal(SSWELEMINCREMENTALWEIGHTPP[ddd]) * (Decimal(600 - ELEMADM[ddd]))))
       else:
           Final_K_8SmWgt.append(GroupAFinalGroupAWeightsK_8)
       #CALCULATION OF VARIABLES FOR GROUP B WEIGHTS
       if d['sumOfDSCSEDMIMRCnt'] == None:
           d['sumOfDSCSEDMIMRCnt'] = 0
       if d['sumOfEDMIMRCnt'] == None:
           d['sumOfEDMIMRCnt'] = 0
       GB1_EDMIDSLD.append(Decimal(d['sumOfEDMIMRCnt']) + Decimal(d['sumOfDSCSEDMIMRCnt']))
       if d['sumOfK3Cnt'] == None:
           d['sumOfK3Cnt'] = 0
       if d['SumOfDSCSK3Cnt'] == None:
           d['SumOfDSCSK3Cnt'] = 0
       GB2_K3Reading.append(Decimal(d['sumOfK3Cnt']) + Decimal(d['SumOfDSCSK3Cnt']))
       GB3_K3.append(Decimal(d['sumOfK3Cnt']) + Decimal(d['SumOfDSCSK3Cnt']))
       if d['sumOfLEPCnt'] == None:
           d['sumOfLEPCnt'] = 0
       if d['sumOfDSCSLEPCnt'] == None:
           d['sumOfDSCSLEPCnt'] = 0
       GB4_ELL.append(Decimal(d['sumOfLEPCnt']) + Decimal(d['sumOfDSCSLEPCnt']))
       if d['sumOfOIResCnt'] == None:
           d['sumOfOIResCnt'] = 0
       if d['sumOfDSCSOIResCnt'] == None:
           d['sumOfDSCSOIResCnt'] = 0
       GB5_OI_R.append(Decimal(d['sumOfOIResCnt']) + Decimal(d['sumOfDSCSOIResCnt']))
       if d['sumOfPSDCnt'] == None:
           d['sumOfPSDCnt'] = 0
       if d['sumOfDSCSPSDCnt'] == None:
           d['sumOfDSCSPSDCnt'] = 0
       GB6_PS_D.append(Decimal(d['sumOfPSDCnt']) + Decimal(d['sumOfDSCSPSDCnt']))
       if d['sumOfMOMRCnt'] == None:
           d['sumOfMOMRCnt'] = 0
       if d['sumOfDSCSMOMRCnt'] == None:
           d['sumOfDSCSMOMRCnt'] = 0
       GB7_MOID.append(Decimal(d['sumOfMOMRCnt']) + Decimal(d['sumOfDSCSMOMRCnt']))
       if d['sumOfHICnt'] == None:
           d['sumOfHICnt'] = 0
       if d['sumOfDSCSHICnt'] == None:
           d['sumOfDSCSHICnt'] = 0
       GB8_HI.append(Decimal(d['sumOfHICnt']) + Decimal(d['sumOfDSCSHICnt']))
       if d['sumOfVICnt'] == None:
           d['sumOfVICnt'] = 0
       if d['sumOfDSCSVICnt'] == None:
           d['sumOfDSCSVICnt'] = 0
       GB9_VI.append(Decimal(d['sumOfVICnt']) + Decimal(d['sumOfDSCSVICnt']))
       if d['sumOfEDPPrivateCnt'] == None:
           d['sumOfEDPPrivateCnt'] = 0
       if d['sumOfDSCSEDPPrivateCnt'] == None:
           d['sumOfDSCSEDPPrivateCnt'] = 0
       GB10_ED_P.append(Decimal(d['sumOfEDPPrivateCnt']) + Decimal(d['sumOfDSCSEDPPrivateCnt']))
       if d['sumOfMDSCCnt'] == None:
           d['sumOfMDSCCnt'] = 0
       if d['sumOfDSCSMDSCCnt'] == None:
           d['sumOfDSCSMDSCCnt'] = 0
       GB11_MDSC.append(Decimal(d['sumOfMDSCCnt']) + Decimal(d['sumOfDSCSMDSCCnt']))
       if d['sumOfMDResCnt'] == None:
           d['sumOfMDResCnt'] = 0
       if d['sumOfDSCSMDResCnt'] == None:
           d['sumOfDSCSMDResCnt'] = 0
       GB12_MD_R.append(Decimal(d['sumOfMDResCnt']) + Decimal(d['sumOfDSCSMDResCnt']))
       if d['sumOfOISCCnt'] == None:
           d['sumOfOISCCnt'] = 0
       if d['sumOfDSCSOISCCnt'] == None:
           d['sumOfDSCSOISCCnt'] = 0
       GB13_OI_SC.append(Decimal(d['sumOfOISCCnt']) + Decimal(d['sumOfDSCSOISCCnt']))
       if d['sumOfMDSSICnt'] == None:
           d['sumOfMDSSICnt'] = 0
       if d['sumOfDSCSMDSSICnt'] == None:
           d['sumOfDSCSMDSSICnt'] = 0
       GB14_MD_SSI.append(Decimal(d['sumOfMDSSICnt']) + Decimal(d['sumOfDSCSMDSSICnt']))
       if d["TEI"] == None:
           d["TEI"] = 0
       #CALCULATION OF TEI
       TEI.append(Decimal(max(TEI10,d["TEI"])))
       #calculation of BASEAMOUNT
       LEABaseLevel.append(Decimal(d["MaxOfBaseAmount"]))
       # calculation of O
       WeightedElemCounts.append(Decimal(ELEMADM[ddd]) * Decimal(Final_K_8SmWgt[ddd]))
       # calculation of P
       WeightedHSCounts.append(Decimal(HSADM[ddd])*Decimal(Final_9_12SmWgt[ddd]))

       # CALCULATION of WEIGHTED PREKCOUNT
       WeightedPreKCounts.append(Decimal(PREKADM[ddd] * Decimal(GroupAFinalGroupAWeightsPSD)))

       # CALCULATION OF PREKBSL
       if d['FTFStatus'] == 1:
           PrekBSL.append(Decimal(TEI[ddd]) * Decimal(LEABaseLevel[ddd]) * Decimal(WeightedPreKCounts[ddd]) * Decimal(HalfTimeAOI))
       elif d['FTFStatus'] == 0:
           PrekBSL.append(Decimal(TEI[ddd]) * Decimal(LEABaseLevel[ddd]) * Decimal(WeightedPreKCounts[ddd]) * Decimal(HalfTimeAOI))
       else:
           PrekBSL.append(Decimal(TEI[ddd]) * Decimal(LEABaseLevel[ddd]) * Decimal(WeightedPreKCounts[ddd]))
       # CALCULATION OF ELEMBSL AND HSBSL
       if (d["FTFStatus"] == HalfTimeAOI):
           ELEMBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedElemCounts[ddd]) * Decimal(HalfTimeAOI))
           HSBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedHSCounts[ddd]) * Decimal(HalfTimeAOI))
       elif (d["FTFStatus"] == FullTimeAOI):
           ELEMBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedElemCounts[ddd]) * Decimal(FullTimeAOI))
           HSBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedHSCounts[ddd]) * Decimal(FullTimeAOI))
       else:
           ELEMBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedElemCounts[ddd]))
           HSBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(WeightedHSCounts[ddd]))
       #CALCULATION OF VARIABLES FOR Q(GROUP B WEIGHTED ADD ON COUNTS) FROM STUDENT COUNTS FY2016_CLEAN
       Weighted_GB1_EDMIDSLD.append(Decimal(GB1_EDMIDSLD[ddd]) * Decimal(GroupB1))
       Weighted_GB2_K3Reading.append(Decimal(GB2_K3Reading[ddd]) * Decimal(GroupB2))
       Weighted_GB3_K3.append(Decimal(GB3_K3[ddd]) * Decimal(GroupB3))
       Weighted_.append(Decimal(GB4_ELL[ddd]) * Decimal(GroupB4))
       Weighted_GB5_OI_R.append(Decimal(GB5_OI_R[ddd]) * Decimal(GroupB5))
       Weighted_GB6_PS_D.append(Decimal(GB6_PS_D[ddd]) * Decimal(GroupB6))
       Weighted_GB7_MOID.append(Decimal(GB7_MOID[ddd]) * Decimal(GroupB7))
       Weighted_GB8_HI.append(Decimal(GB8_HI[ddd]) * Decimal(GroupB8))
       Weighted_GB9_VI.append(Decimal(GB9_VI[ddd]) * Decimal(GroupB9))
       Weighted_GB10_ED_P.append(Decimal(GB10_ED_P[ddd]) * Decimal(GroupB10))
       Weighted_GB11_MDSC.append(Decimal(GB11_MDSC[ddd]) * Decimal(GroupB11))
       Weighted_GB12_MD_R.append(Decimal(GB12_MD_R[ddd]) * Decimal(GroupB12))
       Weighted_GB13_OI_SC.append(Decimal(GB13_OI_SC[ddd]) * Decimal(GroupB13))
       Weighted_GB14_MD_SSI.append(Decimal(GB14_MD_SSI[ddd]) * Decimal(GroupB14))
       #CALCULATION OF GROUP B WEIGHTED ADD ON COUNTS
       GroupBWeightedAddonCounts.append(Weighted_GB1_EDMIDSLD[ddd]+Weighted_GB2_K3Reading[ddd]+Weighted_GB3_K3[ddd]+Weighted_[ddd]+Weighted_GB5_OI_R[ddd]+Weighted_GB6_PS_D[ddd]+Weighted_GB7_MOID[ddd]+Weighted_GB8_HI[ddd]+Weighted_GB9_VI[ddd]+Weighted_GB10_ED_P[ddd]+Weighted_GB11_MDSC[ddd]+Weighted_GB12_MD_R[ddd]+Weighted_GB13_OI_SC[ddd]+Weighted_GB14_MD_SSI[ddd])
       #CALCULATION OF GROUP B BSL
       if (d["FTFStatus"] == HalfTimeAOI):
           GroupBBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(GroupBWeightedAddonCounts[ddd]) * Decimal(HalfTimeAOI))

       elif (d["FTFStatus"] == FullTimeAOI):
           GroupBBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(GroupBWeightedAddonCounts[ddd]) * Decimal(FullTimeAOI))
       else:
           GroupBBSL.append(Decimal(LEABaseLevel[ddd]) * Decimal(TEI[ddd]) * Decimal(GroupBWeightedAddonCounts[ddd]))
       #CALCULATION OF AuditBaseLevelAdjustment
       if (d["FTFStatus"] != None):
           AuditBaseLevelAdjustment.append(Decimal(0))
       else:
           AuditBaseLevelAdjustment.append(Decimal(d["MaxOfBaseAmount"]))
       #CALCULATION OF LOSS FROM SSW OF K-8 FUNDING AND LOSS FROM SSW OF 9-12 FUNDING
       AB2.append(Decimal(LEABaseLevel[ddd]) * Decimal(Final_K_8SmWgt[ddd]) * Decimal(ELEMADM[ddd]))
       AH.append(0)
       #AH.append(Decimal(AB2[ddd])-Decimal(AB2[ddd]*Decimal(sixtyseven/100)))
       AC2.append(Decimal(LEABaseLevel[ddd]) * Decimal(Final_9_12SmWgt[ddd]) * Decimal(HSADM[ddd]))
       AI.append(0)
       #AI.append(Decimal(AC2[ddd]) - Decimal(AC2[ddd] * Decimal(sixtyseven / 100)))
       #CALCULATION OF BSL VALUE
       BSL.append(Decimal(PrekBSL[ddd])+Decimal(ELEMBSL[ddd])+Decimal(HSBSL[ddd])+Decimal(GroupBBSL[ddd])+Decimal(AuditBaseLevelAdjustment[ddd]))
       #STORING ENTITY ID
       EID.append(d['EntityID'])
       #STORING ENTITY NAME
       Ename.append(d['EntityName'])

       #CALCULATION OF TOTOAL NET CHARTER AA
       LEApercentofCharterElemADM.append(Decimal(CharterElemADM[ddd] / sum(CharterElemADM)))
       LEApercentofCharterHSADM.append(Decimal(CharterHSADM[ddd] / sum(CharterHSADM)))
       K_8PercentofTotalcharterAA.append(Decimal(sum(CharterElemAA) / (sum(CharterElemAA) + sum(CharterHSAA))))
       TotalCharterElemReduction.append(Decimal(CharterReduction) * Decimal(K_8PercentofTotalcharterAA[ddd]))
       TotalCharterHSReduction.append(Decimal(CharterReduction) * Decimal((1 - Decimal(K_8PercentofTotalcharterAA[ddd]))))
       CharterElemAAReduction.append(Decimal(LEApercentofCharterElemADM[ddd]) * Decimal(TotalCharterElemReduction[ddd]))
       CharterHSAAReduction.append(Decimal(LEApercentofCharterHSADM[ddd]) * Decimal(TotalCharterHSReduction[ddd]))
       TotalNetCharterAA.append(Decimal(CharterElemAA[ddd] + CharterHSAA[ddd]) - (Decimal(CharterElemAAReduction[ddd] + CharterHSAAReduction[ddd])))

       #CALCULATION OF FINAL FORUMULAADDITIONALASSISTANCE
       if d['Type'] == "Charter":
           DistrictHSTextbooksAA.append(0)
           DistrictHSAA.append(0)
           DistrictElemAA.append(0)
           DistrictPreKAA.append(0)
           DistrictPreKElemReduction.append(Decimal(0))
           DistrictHSReduction.append(Decimal(0))
           TotalDistrictAAReduction.append(Decimal(0))
           TotalFormulaDistrictAA.append(Decimal(0))
           TotalNetDistrictAA.append(Decimal(0))
           FinalFormulaAAwithReduction.append(Decimal(TotalNetCharterAA[ddd]))
           FinalFormulaAdditionalAssistance.append(Decimal(CharterElemAA[ddd] + CharterHSAA[ddd]))
       else:
           if AdditionalAssistant_eqformula == 2:
               DistrictHSTextbooksAA.append(0)
               DistrictHSAA.append(Decimal(CharSuppLvlAll9_12 * HSADM[ddd]))
               DistrictElemAA.append(Decimal(CharSuppLvlAllK_8 * ELEMADM[ddd]))
               DistrictPreKAA.append(Decimal(CharSuppLvlAllK_8 * PREKADM[ddd]))

           else:
               if d['HsBooksCapOutlayRevLimitAmt'] == None:
                   d['HsBooksCapOutlayRevLimitAmt'] = 0
               if d['HsPrlmCapOutlayRevLimitAmt'] == None:
                   d['HsPrlmCapOutlayRevLimitAmt'] = 0
               if d['ElemCapOutlayRevLimitAmt'] == None:
                   d['ElemCapOutlayRevLimitAmt'] = 0
               if d['PsdCapOutlayRevLimitAmt'] == None:
                   d['PsdCapOutlayRevLimitAmt'] = 0
               DistrictHSTextbooksAA.append(Decimal(d['HsBooksCapOutlayRevLimitAmt']))
               DistrictHSAA.append(Decimal(d['HsPrlmCapOutlayRevLimitAmt']))
               DistrictElemAA.append(Decimal(d['ElemCapOutlayRevLimitAmt']))
               DistrictPreKAA.append(Decimal(d['PsdCapOutlayRevLimitAmt']))

           if d['PSElTransAdj'] == None:
               d['PSElTransAdj'] = 0
           if d['HSTransAdj'] == None:
               d['HSTransAdj'] = 0
           DistrictPreKElemReduction.append(Decimal(d['PSElTransAdj']))
           DistrictHSReduction.append(Decimal(d['HSTransAdj']))
           TotalDistrictAAReduction.append(Decimal(DistrictPreKElemReduction[ddd] + DistrictHSReduction[ddd]))
           TotalFormulaDistrictAA.append(Decimal(DistrictHSTextbooksAA[ddd] + DistrictHSAA[ddd] + DistrictElemAA[ddd] + DistrictElemAA[ddd] + DistrictPreKAA[ddd]))
           TotalNetDistrictAA.append(Decimal(TotalFormulaDistrictAA[ddd] + TotalDistrictAAReduction[ddd]))
           FinalFormulaAAwithReduction.append(TotalNetDistrictAA[ddd])
           FinalFormulaAdditionalAssistance.append(TotalFormulaDistrictAA[ddd])
       #CALCULATION OF FINALAAALLOCATION
       if AdditonalAssistantReduction == 1:
           FinalAAAllocation.append(FinalFormulaAAwithReduction[ddd])
       else:
           FinalAAAllocation.append(FinalFormulaAdditionalAssistance[ddd])
       AdditionalAssistance.append(FinalAAAllocation[ddd])
       OppurtunityWeight.append(Decimal(0))
       if d['TRCL']==None:
           d['TRCL']=0
       if d['TSL']==None:
           d['TSL']=0
       TRCL.append(Decimal(d['TRCL']))
       TSL.append(Decimal(d['TSL']))
       RCL.append(Decimal(BSL[ddd])+AdditionalAssistance[ddd]+OppurtunityWeight[ddd]+TRCL[ddd])
       DSL.append(Decimal(BSL[ddd]+AdditionalAssistance[ddd]+OppurtunityWeight[ddd]+TSL[ddd]))


       TotalStateEqualisationFunding.append(min(RCL[ddd], DSL[ddd]))

       #CALCULATION OF  WEIGHTED PUPILS USER SPECIFIED SSW REDUCTION
       PreKWeightedPupilsuser_specifiedSWWreduction.append(Decimal(Decimal(PREKADM[ddd]*Decimal(GroupAFinalGroupAWeightsPSD))-0))
       K_8WeightedPupilsuser_specifiedSWWreduction.append((Decimal(ELEMADM[ddd])*Decimal(Final_K_8SmWgt[ddd]))-0)
       nine_12WeightedPupilsuser_specifiedSWWreduction.append((Decimal(HSADM[ddd])*Decimal(Final_9_12SmWgt[ddd]))-0)
       SumofPreKWeightedPupilsuser_specifiedSWWreduction[d['EntityID']] +=PreKWeightedPupilsuser_specifiedSWWreduction[ddd]
       Sumofk_8WeightedPupilsuser_specifiedSWWreduction[d['EntityID']] += K_8WeightedPupilsuser_specifiedSWWreduction[ddd]
       Sumof9_12WeightedPupilsuser_specifiedSWWreduction[d['EntityID']] +=nine_12WeightedPupilsuser_specifiedSWWreduction[ddd]
       ddd += 1
   dd4=0

   result3 = engine.execute('select truck.*,lorry.PsdCapOutlayRevLimitAmt,lorry.ElemCapOutlayRevLimitAmt,lorry.HsPrlmCapOutlayRevLimitAmt,lorry.HsBooksCapOutlayRevLimitAmt,lorry.PSElTransAdj,lorry.HSTransAdj from (select kvs.*, CSH.parentOrganization, CSH.NetworkForFundingPurposes, CSH.ESSmallIsolated, CSH.HSSmallIsolated from (select ftfmaintype.*,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (Select ftfmain.*,EntityName,Entityshort.County,Entityshort.Type from (select EntityID,sum(PsdCount) as sumOfPsdCount,sum(ElemCount) as sumOfElemCount,sum(DSCSElemCnt) as sumOfDSCSElemCount,sum(HsCount) as sumOfHsCount, sum(DSCSHsCnt) as sumOfDSCSHsCount, FiscalYear,TEI,BaseAmount as MaxOfBaseAmount,sum(MDSSICnt) as sumOfMDSSICnt, sum(DSCSMDSSICnt)as sumOfDSCSMDSSICnt, sum(DSCSVICnt)as sumOfDSCSVICnt, sum(DSCSOISCCnt) as sumOfDSCSOISCCnt, sum(DSCSPSDCnt)as sumOfDSCSPSDCnt, sum(DSCSMDSCCnt)as sumOfDSCSMDSCCnt, sum(DSCSHICnt)as sumOfDSCSHICnt, sum(DSCSMOMRCnt)as sumOfDSCSMOMRCnt, sum(DSCSEDPPrivateCnt)as sumOfDSCSEDPPrivateCnt, sum(DSCSMDResCnt)as sumOfDSCSMDResCnt, sum(DSCSOIResCnt)as sumOfDSCSOIResCnt, sum(DSCSEDMIMRCnt)as sumOfDSCSEDMIMRCnt, sum(DSCSLEPCnt)as sumOfDSCSLEPCnt, sum(DSCSK3Cnt)as SumOfDSCSK3Cnt, sum(PSDCnt)as sumOfPSDCnt, sum(VICnt)as sumOfVICnt, sum(OISCCnt)as sumOfOISCCnt, sum(MDSCCnt)as sumOfMDSCCnt, sum(HICnt)as sumOfHICnt, sum(MOMRCnt)as sumOfMOMRCnt, sum(EDPPrivateCnt)as sumOfEDPPrivateCnt, sum(MDResCnt)as sumOfMDResCnt, sum(OIResCnt)as sumOfOIResCnt, sum(EDMIMRCnt)as sumOfEDMIMRCnt, sum(LEPCnt)as sumOfLEPCnt, sum(K3Cnt)as sumOfK3Cnt, FTFStatus from (select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaAporBaseSupportLevelCalcs where PaymentMonth=14 union all select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,MDSSICnt,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaCharBaseSupportLevelCalcs where PaymentMonth=13)uni where FiscalYear=2017 group by EntityID,FTFStatus )ftfmain left join (select EntityID,EntityName,County,Entity.Type from Entity)Entityshort on ftfmain.EntityID=Entityshort.EntityID )ftfmaintype left join (select TRCLTSL.EntityID,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (select TRCL.EntityID,TRCL,TSL from (select EntityID,TRCL from SaAporTransRevCtlLimit where FiscalYear=2017 and PaymentMonth=14)TRCL left join (select EntityID,TSL from SaAporTransSupptLvl where FiscalYear=2017 and PaymentMonth=14)TSL on TRCL.EntityID=TSL.EntityID)TRCLTSL left join (Select EntityID,TotalPSElAssessValAmt,TotalHSAssessValAmt from SaAporQualLevy where FiscalYear=2017 and PaymentMonth=14)PSEl on TRCLTSL.EntityID=PSEl.EntityID )Bike on ftfmaintype.EntityID=Bike.EntityID) kvs left join (select CWN.EntityID, CWN.EntityName, CWN.parentOrganization, CWN.NetworkForFundingPurposes, ESSmallIsolated, HSSmallIsolated from (select EntityID, ChartersWithNetwork.OrganizationName as EntityName, ParentOrganization, ifnull(Charters4Funding.NetworkForFundingPurposes,0) as NetworkForFundingPurposes  from ChartersWithNetwork left join Charters4Funding on ChartersWithNetwork.ParentOrganization = Charters4Funding.OrganizationName) CWN left join SmallIsolatedList on CWN.EntityID = SmallIsolatedList.EntityID)CSH on kvs.EntityID = CSH.EntityID)truck left join(select car1.EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt,PSElTransAdj,HSTransAdj from (select EntityID,PsdCapOutlayRevLimitAmt,ElemCapOutlayRevLimitAmt,HsPrlmCapOutlayRevLimitAmt,HsBooksCapOutlayRevLimitAmt from SaAporCapitalOutlayCalcs where FiscalYear=2017 and PaymentMonth=14 )bike1 left join (select EntityID,PSElTransAdj,HSTransAdj from SaAporSoftCapAlloc where FiscalYear=2017 and PaymentMonth=14 )car1 on car1.EntityID=bike1.EntityID)lorry on lorry.EntityID=truck.EntityID')
   for row in result3:
       d11={}
       # Creating a dictionary of the values retrieved from the query
       d4 = dict(row.items())
       # MAKING THE TYPE OF SCHOOL COMPACT FOR CALCULATIONS
       if (d4['Type'] == 'Charter Holder-Charter Board'):
           d4['Type']="Charter"
       elif (d4['Type'] =='Charter Holder - University'):
           d4['Type']="Charter"
       elif (d4['Type']== 'School District - Vocational/Technical'):
           d4['Type']="JTED"
       else:
           d4['Type']="District"
       #CALCULATION OF PERCENTAGE OF PREK_8 OF TOTAL AND HS OF TOTAL
       temp5=SumofPreKWeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]+Sumofk_8WeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]

       temp6=SumofPreKWeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]+Sumof9_12WeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]+Sumofk_8WeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]

       temp7=Sumof9_12WeightedPupilsuser_specifiedSWWreduction[d4['EntityID']]
       if temp6==0:
           PercPreK_8ofTotal.append(float(0))
           PercHSofTotal.append(float(0))
       else:
           PercPreK_8ofTotal.append(float(temp5)/float(temp6))
           PercHSofTotal.append(float(temp7)/float(temp6))
       #CALCULATION OF ELEMENTARY AND HSTOTALSTATE FORMULA
       ElemTotalStateFormula.append(Decimal(TotalStateEqualisationFunding[dd4])*Decimal(PercPreK_8ofTotal[dd4]))
       HSTotalStateFormula.append(Decimal(TotalStateEqualisationFunding[dd4])*Decimal(PercHSofTotal[dd4]))
       #CALCULATION OF lOCAL LEVY
       if d4['TotalHSAssessValAmt']==None:
           d4['TotalHSAssessValAmt']=0
       HSAssessedValuation.append(Decimal(d4['TotalHSAssessValAmt']))
       if HSADM[dd4]==0:
           HSQTRYield.append(0)
       elif d4['Type']=="JTED":
           HSQTRYield.append(Decimal(HSAssessedValuation[dd4])*Decimal(0.01)*Decimal(QTRJTED))
       else:
           HSQTRYield.append(Decimal(HSAssessedValuation[dd4])*Decimal(0.01)*Decimal(QTR9_12))
       HSLL.append(min(HSTotalStateFormula[dd4],HSQTRYield[dd4]))
       if d4['TotalPSElAssessValAmt']==None:
           d4['TotalPSElAssessValAmt']=0
       ElemAssessedValuation.append(Decimal(d4['TotalPSElAssessValAmt']))
       if ELEMADM[dd4]==0:
           ElemQTRYield.append(0)
       else:
           ElemQTRYield.append(Decimal(ElemAssessedValuation[dd4])*Decimal(QTRK_8)*Decimal(0.01))
       ElemLL.append(min(ElemTotalStateFormula[dd4],ElemQTRYield[dd4]))
       TotalLocalLevy.append(ElemLL[dd4]+HSLL[dd4])
       #CALCUALTION OF TOTAL STATE AID
       if ElemTotalStateFormula[dd4]>ElemQTRYield[dd4]:
           ElemStateAid.append(Decimal(ElemTotalStateFormula[dd4]-ElemQTRYield[dd4]))
       else:
           ElemStateAid.append(0)
       if HSTotalStateFormula[dd4]>HSQTRYield[dd4]:
           HSStateAid.append(Decimal(HSTotalStateFormula[dd4]-HSQTRYield[dd4]))
       else:
           HSStateAid.append(0)
       TotalStateAid.append(ElemStateAid[dd4]+HSStateAid[dd4])
       #CALCULATION OF NO STATE AID
       if ((PREKADM[dd4]+ELEMADM[dd4])>0) and (ElemStateAid[dd4]==0):
           ElemNoStateAidDistrict.append(Decimal(1))
       else:
           ElemNoStateAidDistrict.append(Decimal(0))
       if (HSADM[dd4]>0) and (HSStateAid[dd4]==0):
           HSNoStateAidDistrict.append(Decimal(1))
       else:
           HSNoStateAidDistrict.append(Decimal(0))
       if((ElemNoStateAidDistrict[dd4]+HSNoStateAidDistrict[dd4])>0) and (TotalStateAid[dd4]==0):
            NoStateAidDistrict.append(Decimal(1))
       else:
            NoStateAidDistrict.append(Decimal(0))
       TotalQTRYield.append(Decimal(ElemQTRYield[dd4]+HSQTRYield[dd4]))
       UncapturedQTR.append(Decimal(TotalQTRYield[dd4]-TotalLocalLevy[dd4]))
       TotalStateFundingEqualised.append(Decimal(ElemTotalStateFormula[dd4]+HSTotalStateFormula[dd4]))
       d11['EntityID'] = EID[dd4]
       d11['NoStateAidDistrict'] = str(round(NoStateAidDistrict[dd4],3))
       d11['EntityName'] = Ename[dd4]
       d11['County']=d4['County']
       d11['AOI']=str(d4['FTFStatus'])
       d11['BSL']=str(round(BSL[dd4],3))
       d11['TotalLocalLevy'] = str(round(TotalLocalLevy[dd4],3))
       d11['UncapturedQTR'] = str(round(UncapturedQTR[dd4],3))
       d11['TotalStateAid'] = str(round(TotalStateAid[dd4],3))
       d11['TotalStateFundingEqualised'] = str(round(TotalStateFundingEqualised[dd4],3))
       D.append(d11)
       dd4+=1
   return render_template('table2.html', string1=D)

@app.route('/PreBSL')
def PreBSL():
    S = []
    R = []
    N = []
    #query to calculate ADM values
    admresult = engine.execute('select EntityID,(PsdCount) as sumOfPsdCount,sum(ElemCount) as sumOfElemCount,sum(DSCSElemCnt) as sumOfDSCSElemCount,sum(HsCount) as sumOfHsCount, sum(DSCSHsCnt) as sumOfDSCSHsCount,sum(DSCSK3Cnt) as SumOfDSCSK3Cnt from SaAporBaseSupportLevelCalcs where FiscalYear=2017 group by EntityID ;')

    # k is 5th column
    # L is th column
    HSADM = []
    # full day kindergarden
    fDK = 0
    ELEMADM = []
    PREKADM = []
    TOTALADM = []
    PrekBSL=[]
    OldSSWELEMIncementalWeightPP=[]
    g=0
    #for row in admresult:
        # print(row)
        #HSADM.append(row[4] + row[5])
        # print(HSADM)
        #Calculation of PREKADM
        #PREKADM.append(row[1])
        #calculating N value using PREKADM
     #   N.append(PREKADM[g]*Decimal(df["GroupAFinalGroupAWeightsPSD"][0]))
      #  g=g+1
        # print(PREKADM)
        #if fDK == 0:
         #   ELEMADM.append(row[2] + row[3])
            # print(ELEMADM)


    #for i in range(0, len(PREKADM)):
     #   TOTALADM.append(PREKADM[i] + ELEMADM[i] + HSADM[i])
    #query for ftf values calculation
    ftfresult = engine.execute('select ftfmaintype.*,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (Select ftfmain.*,EntityName,Entityshort.Type from (select EntityID,sum(PsdCount) as sumOfPsdCount,sum(ElemCount) as sumOfElemCount,sum(DSCSElemCnt) as sumOfDSCSElemCount,sum(HsCount) as sumOfHsCount, sum(DSCSHsCnt) as sumOfDSCSHsCount, FiscalYear,TEI,BaseAmount as MaxOfBaseAmount, sum(DSCSMDSSICnt)as sumOfDSCSMDSSICnt, sum(DSCSVICnt)as sumOfDSCSVICnt, sum(DSCSOISCCnt) as sumOfDSCSOISCCnt, sum(DSCSPSDCnt)as sumOfDSCSPSDCnt, sum(DSCSMDSCCnt)as sumOfDSCSMDSCCnt, sum(DSCSHICnt)as sumOfDSCSHICnt, sum(DSCSMOMRCnt)as sumOfDSCSMOMRCnt, sum(DSCSEDPPrivateCnt)as sumOfDSCSEDPPrivateCnt, sum(DSCSMDResCnt)as sumOfDSCSMDResCnt, sum(DSCSOIResCnt)as sumOfDSCSOIResCnt, sum(DSCSEDMIMRCnt)as sumOfDSCSEDMIMRCnt, sum(DSCSLEPCnt)as sumOfDSCSLEPCnt, sum(DSCSK3Cnt)as sumOfDSCSK3Cnt, sum(PSDCnt)as sumOfPSDCnt, sum(VICnt)as sumOfVICnt, sum(OISCCnt)as sumOfOISCCnt, sum(MDSCCnt)as sumOfMDSCCnt, sum(HICnt)as sumOfHICnt, sum(MOMRCnt)as sumOfMOMRCnt, sum(EDPPrivateCnt)as sumOfEDPPrivateCnt, sum(MDResCnt)as sumOfMDResCnt, sum(OIResCnt)as sumOfOIResCnt, sum(EDMIMRCnt)as sumOfEDMIMRCnt, sum(LEPCnt)as sumOfLEPCnt, sum(K3Cnt)as sumOfK3Cnt, FTFStatus from (select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaAporBaseSupportLevelCalcs where PaymentMonth=14 union all select EntityID,FiscalYear,PsdCount,ElemCount,DSCSElemCnt,HsCount,DSCSHsCnt,DSCSK3Cnt,TEI,PaymentMonth,FTFStatus,BaseAmount,DSCSMDSSICnt, DSCSVICnt,DSCSOISCCnt,DSCSPSDCnt,DSCSMDSCCnt,DSCSHICnt,DSCSMOMRCnt,DSCSEDPPrivateCnt,DSCSMDResCnt,DSCSOIResCnt,DSCSEDMIMRCnt,DSCSLEPCnt,PSDCnt,VICnt,OISCCnt, MDSCCnt,HICnt,MOMRCnt,EDPPrivateCnt,MDResCnt,OIResCnt,EDMIMRCnt,LEPCnt,K3Cnt from SaCharBaseSupportLevelCalcs where PaymentMonth=13)uni where FiscalYear=2017 group by EntityID,FTFStatus )ftfmain left join (select EntityID,EntityName,Entity.Type from Entity)Entityshort on ftfmain.EntityID=Entityshort.EntityID )ftfmaintype left join (select TRCLTSL.EntityID,TRCL,TSL,TotalPSElAssessValAmt,TotalHSAssessValAmt from (select TRCL.EntityID,TRCL,TSL from (select EntityID,TRCL from SaAporTransRevCtlLimit where FiscalYear=2017 and PaymentMonth=14)TRCL left join (select EntityID,TSL from SaAporTransSupptLvl where FiscalYear=2017 and PaymentMonth=14)TSL on TRCL.EntityID=TSL.EntityID)TRCLTSL left join (Select EntityID,TotalPSElAssessValAmt,TotalHSAssessValAmt from SaAporQualLevy where FiscalYear=2017 and PaymentMonth=14)PSEl on TRCLTSL.EntityID=PSEl.EntityID )Bike on ftfmaintype.EntityID=Bike.EntityID')
    #print("PREKADM is :")
    #print(PREKADM)

    for row in ftfresult:
        #storing ftf results as dictionary in di
        di = dict(row.items())
        if di['sumOfHsCount'] == None:
            di['sumOfHsCount'] = 0
        if di['sumOfDSCSHsCount'] == None:
            di['sumOfDSCSHsCount'] = 0
        HSADM.append(di['sumOfHsCount'] + di['sumOfDSCSHsCount'])
        if di['sumOfPsdCount']==None:
            di['sumOfPsdCount']=0

        PREKADM.append(di['sumOfPsdCount'])
        if PREKADM[g] == None:
            PREKADM[g] = 0
        N.append(Decimal(PREKADM[g] * Decimal(GroupAFinalGroupAWeightsPSD)))

        if fDK == 0:
            if di['sumOfElemCount']== None:
                di['sumOfElemCount']=0
            if di['sumOfDSCSElemCount']== None:
                di['sumOfDSCSElemCount']=0
            ELEMADM.append(di['sumOfElemCount'] + di['sumOfDSCSElemCount'])
        if di["TEI"] == None:
            di["TEI"] = 0
        #calculation of S
        S.append(Decimal(max((TEI10), di["TEI"])))
        #calculation of E
        R.append(Decimal(di["MaxOfBaseAmount"]))
        if di['FTFStatus']==1:
            PrekBSL.append(Decimal(S[g]) * Decimal(R[g]) * Decimal(N[g]) * Decimal(HalfTimeAOI))
        elif di['FTFStatus']==0:
            PrekBSL.append(Decimal(S[g]) * Decimal(R[g]) * Decimal(N[g]) * Decimal(HalfTimeAOI))
        else:

            PrekBSL.append(Decimal(S[g]) * Decimal(R[g]) * Decimal(N[g]))

        for i in range(0, len(PREKADM)):
            TOTALADM.append(PREKADM[i] + ELEMADM[i] + HSADM[i])

        #N.append(PREKADM[int(row)]*Decimal(df["GroupAFinalGroupAWeightsPSD"][0]))


    return render_template('table.html')

if __name__ == '__main__':
   app.run()
